import javax.swing.*;

public class menuForm {
    private JTabbedPane Menu;
    private JPanel showMenu;
    private JPanel addToMenu;
    private JList list1;
    private JRadioButton radioButton1;


}
