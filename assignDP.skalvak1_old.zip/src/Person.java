public abstract class Person {
    private ProductMenu theProductMenu;

    private Buyer buyer;

    private ProductMenu productMenu;

    public void showMenu() {

    }

    public void showAddButton() {

    }

    public void showViewButton() {

    }

    public void showRadioButton() {

    }

    public void showLabels() {

    }

    public abstract ProductMenu createProductMenu(int nProductCategory);
}
