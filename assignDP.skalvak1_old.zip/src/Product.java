public class Product {


        private Trading trading;

        private ClassProductList classProductList;
        public String ProductCategory;
        public String ProductIs;

        public Product(String type,String name){
            this.ProductCategory = type;
            this.ProductIs=name;

        }


}
