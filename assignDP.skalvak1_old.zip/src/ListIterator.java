import java.util.Iterator;
public interface ListIterator {
    public boolean hasNext() ;


    public Product Next();

    public void MoveToHead() ;

    public void Remove() ;
}
