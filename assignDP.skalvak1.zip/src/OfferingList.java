public class OfferingList {
}
