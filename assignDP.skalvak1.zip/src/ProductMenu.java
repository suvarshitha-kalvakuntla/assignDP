import java.util.ArrayList;

public interface ProductMenu {
    public ArrayList showMenu(ClassProductList theProductList) ;
}
