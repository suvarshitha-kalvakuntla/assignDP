public class Main {
    public static void main(String [] args){
        Facade d=new Facade();
        System.out.println("Implementing facade Design Pattern");
        d.login();}
}